# CKD
Chronic Kidney Disease Prediction Using Machine Learning Algorithm
